/*
    Q] Armstrong Number

         num = 153
         sum = 1cube + 5cube + 3cube 
             = 153
*/

       import java.util.Scanner;
    
    public class ArmstrongNumber
    {
        public static void main(String [] args)
        {
           Scanner s = new Scanner(System.in);
             int num, rem, sum=0;

            System.out.println("\n Enter a num : ");
              num = s.nextInt();
 
               int temp = num;

              while(num != 0)
              {
                 rem = num % 10;
                 sum = sum + (int)Math.pow(rem, 3);
                 num = num / 10;
              }

        if(temp == sum)
          System.out.println("\n Armstrong Number ");
        else
          System.out.println("\n Not an Armstrong Number ");
        }
    }
   