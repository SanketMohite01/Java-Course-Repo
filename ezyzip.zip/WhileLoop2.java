    
    public class WhileLoop2
    {
        public static void main(String [] args)
        {
              int x=5;    

             while(x >= 1)
             {
                System.out.println(x);

                  x--; 
             }
        }
    }
   
