/*
   Q] Insertion in sorted array
*/

       import java.util.Scanner;
    
    public class ArrayDemo7
    {
        public static void main(String [] args)
        {
           Scanner s = new Scanner(System.in);
             int size, i, num, pos;
               
           System.out.println("\n Enter size : ");
              size = s.nextInt();

                pos = size;

             int [] x = new int[size+1];

         System.out.println("\n Enter nums (in asc order): ");
            for(i=0; i<size ; i++)
            {
                 x[i] = s.nextInt();  
            }

         System.out.println("\n Enter num to be inserted : ");
              num = s.nextInt();

            for(i=0 ; i<size ; i++)
            {
                if(num < x[i])
                {
                    pos = i;
                    break;
                } 
            } 

          for(i=size ; i>pos ; i--)
          {
              x[i] = x[i-1]; 
          }  

             x[pos] = num;

        System.out.println("\n List after insertion : ");
            for(i=0 ; i<=size ; i++)
            {
               System.out.print("  "+x[i]);
            }
        }
    }
