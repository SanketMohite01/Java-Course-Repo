
       import java.util.Scanner;
    
    public class RowSum
    {
        public static void main(String [] args)
        {
           Scanner s = new Scanner(System.in);
 
              int [][] A = new int[3][3];
                   int i, j, sum;

            System.out.println("\n Enter 9 nums : ");     
                for(i=0 ; i<3; i++)
                  for(j=0 ; j<3; j++)
                    A[i][j] = s.nextInt();


            System.out.println("\n Sum of each row : ");     
                for(i=0 ; i<3; i++)
                {
                     sum =0;

                   for(j=0 ; j<3; j++)
                   {
                       sum += A[i][j];
                   }

                   System.out.println("\n sum = "+sum);      
                }   
        }
    }
   
