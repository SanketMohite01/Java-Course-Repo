/*
   Q] deletion from array
*/

       import java.util.Scanner;
    
    public class ArrayDemo8
    {
        public static void main(String [] args)
        {
           Scanner s = new Scanner(System.in);
             int size, i, num, pos=-1;
               
           System.out.println("\n Enter size : ");
              size = s.nextInt();

             int [] x = new int[size+1];

         System.out.println("\n Enter nums : ");
            for(i=0; i<size ; i++)
            {
                 x[i] = s.nextInt();  
            }

         System.out.println("\n Enter num to be deleted : ");
              num = s.nextInt();

         for(i=0 ; i<size ; i++)
         {
             if(num == x[i])
             {
                 pos = i;
                 break; 
             } 
         }

           if(pos == -1)
           {
               System.out.println("\n NUM NOT FOUND ");
                    System.exit(0);
           }

                   x[pos] = 0;

              for(i=pos ; i<size-1 ; i++)
              {
                  x[i] = x[i+1];  
              }

           System.out.println("\n List after deletion : ");
               for(i=0 ; i<size-1 ; i++)
               {
                   System.out.print("  "+x[i]);
               }
        }
    }
