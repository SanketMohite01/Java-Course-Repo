/*
   Q] Container with most water
*/
    
    public class LeetCode2
    {
        public static void main(String [] args)
        {
            int [] heights={1,8,6,2,5,4,8,3,7};
            int i,j, width, height, maxarea=0;

            for(i=0,j=heights.length-1 ; i<j ; )
            {
                    width = j-i;
           height = (heights[i]<heights[j])?heights[i]:heights[j];
                   
                    if(maxarea <= (width*height))
                    {
                        maxarea = width*height;
                    }

                if(heights[i] <= heights[j])
                {
                     i++;
                }
                else
                {
                     j--;
                }
            }
 
            System.out.println("\n maxarea = "+maxarea);
        }
    }
