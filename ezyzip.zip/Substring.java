
    public class Substring
    {
        public static void main(String [] args)
        {
            String s1 = "computer";
 
            String s2 = s1.substring(0, 4); 

            System.out.println("\n s2 = "+s2);
        }
    }
 




