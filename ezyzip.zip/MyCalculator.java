        import javax.swing.*;
        import java.awt.*;
        import java.awt.event.*;

      class MyFrame extends JFrame 
      {
           JLabel l1, l2, l3;
           JTextField t1, t2, t3;
           JButton b1, b2, b3, b4, b5; 

           public MyFrame()
           {
               super("MyCalculator");
               setSize(800, 500);
               setLocation(300, 300);
               setResizable(false);
               setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
               setLayout(null);
 
               l1 = new JLabel("ENTER FIRST NUMBER : ");
               l1.setFont(new Font("consolas", Font.BOLD, 27));
               l1.setForeground(Color.BLACK);
               l1.setBounds(20, 20, 350, 50);//(x,y,w,h)
               add(l1);

               t1 = new JTextField();
               t1.setFont(new Font("consolas", Font.BOLD, 27));
               t1.setForeground(Color.BLACK);
               t1.setBounds(380, 20, 350, 50);//(x,y,w,h)
               add(t1);

               l2 = new JLabel("ENTER SECOND NUMBER : ");
               l2.setFont(new Font("consolas", Font.BOLD, 27));
               l2.setForeground(Color.BLACK);
               l2.setBounds(20, 90, 350, 50);//(x,y,w,h)
               add(l2);

               t2 = new JTextField();
               t2.setFont(new Font("consolas", Font.BOLD, 27));
               t2.setForeground(Color.BLACK);
               t2.setBounds(380, 90, 350, 50);//(x,y,w,h)
               add(t2);

               b1 = new JButton(" ADD ");
               b1.setFont(new Font("consolas", Font.BOLD, 27));
               b1.setForeground(Color.BLACK);
               b1.setBounds(20, 160, 150, 50);//(x,y,w,h)
               add(b1);

               b2 = new JButton(" SUB ");
               b2.setFont(new Font("consolas", Font.BOLD, 27));
               b2.setForeground(Color.BLACK);
               b2.setBounds(190, 160, 150, 50);//(x,y,w,h)
               add(b2);

               b3 = new JButton(" MUL ");
               b3.setFont(new Font("consolas", Font.BOLD, 27));
               b3.setForeground(Color.BLACK);
               b3.setBounds(360, 160, 150, 50);//(x,y,w,h)
               add(b3);

               b4 = new JButton(" DIV ");
               b4.setFont(new Font("consolas", Font.BOLD, 27));
               b4.setForeground(Color.BLACK);
               b4.setBounds(530, 160, 150, 50);//(x,y,w,h)
               add(b4);

               l3 = new JLabel(" ANSWER : ");
               l3.setFont(new Font("consolas", Font.BOLD, 27));
               l3.setForeground(Color.BLACK);
               l3.setBounds(20, 240, 350, 50);//(x,y,w,h)
               add(l3);

               t3 = new JTextField();
               t3.setFont(new Font("consolas", Font.BOLD, 27));
               t3.setForeground(Color.BLACK);
               t3.setBounds(380, 240, 350, 50);//(x,y,w,h)
               add(t3);

               b5 = new JButton(" CLEAR ALL ");
               b5.setFont(new Font("consolas", Font.BOLD, 27));
               b5.setForeground(Color.BLACK);
               b5.setBounds(160, 330, 300, 50);//(x,y,w,h)
               add(b5);

        b1.addActionListener(new ActionListener()
        {
             public void actionPerformed(ActionEvent e)
             {

   if(t1.getText().equals("") || t2.getText().equals(""))
   {
      JOptionPane.showMessageDialog(MyFrame.this, "PLEASE ENTER NUMBERS", "ERROR", JOptionPane.PLAIN_MESSAGE);
  
          return;
   }

                double n1 = Double.parseDouble(t1.getText());
                double n2 = Double.parseDouble(t2.getText());
   
                   double ans = n1 + n2;
 
                   t3.setText(ans+"");  
             }
        });

        b2.addActionListener(new ActionListener()
        {
             public void actionPerformed(ActionEvent e)
             {
   if(t1.getText().equals("") || t2.getText().equals(""))
   {
      JOptionPane.showMessageDialog(MyFrame.this, "PLEASE ENTER NUMBERS", "ERROR", JOptionPane.PLAIN_MESSAGE);
  
          return;
   }

                double n1 = Double.parseDouble(t1.getText());
                double n2 = Double.parseDouble(t2.getText());
   
                   double ans = n1 - n2;
 
                   t3.setText(ans+"");  
             }
        });

        b3.addActionListener(new ActionListener()
        {
             public void actionPerformed(ActionEvent e)
             {
   if(t1.getText().equals("") || t2.getText().equals(""))
   {
      JOptionPane.showMessageDialog(MyFrame.this, "PLEASE ENTER NUMBERS", "ERROR", JOptionPane.PLAIN_MESSAGE);
  
          return;
   }

                double n1 = Double.parseDouble(t1.getText());
                double n2 = Double.parseDouble(t2.getText());
   
                   double ans = n1 * n2;
 
                   t3.setText(ans+"");  
             }
        });

        b4.addActionListener(new ActionListener()
        {
             public void actionPerformed(ActionEvent e)
             {
   if(t1.getText().equals("") || t2.getText().equals(""))
   {
      JOptionPane.showMessageDialog(MyFrame.this, "PLEASE ENTER NUMBERS", "ERROR", JOptionPane.PLAIN_MESSAGE);
  
          return;
   }

                double n1 = Double.parseDouble(t1.getText());
                double n2 = Double.parseDouble(t2.getText());
   
                   double ans = n1 / n2;
 
                   t3.setText(ans+"");  
             }
        });

        b5.addActionListener(new ActionListener()
        {
             public void actionPerformed(ActionEvent e)
             {
                     t1.setText(" ");
                     t2.setText(" ");
                     t3.setText(" ");
             }
        });

               setVisible(true);
           }
     }
  

    public class MyCalculator
    {
        public static void main(String [] args)
        {
             new MyFrame();
        }
    }
   
