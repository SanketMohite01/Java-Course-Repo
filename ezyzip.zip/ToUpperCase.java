
    public class ToUpperCase
    {
        public static void main(String [] args)
        {
            String s1 = "Computer";

            String s2 = s1.toUpperCase();
 
            System.out.println("\n s1 = "+s1);
            System.out.println("\n s2 = "+s2);
        }
    }
   




