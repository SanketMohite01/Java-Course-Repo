
    public class Replace
    {
        public static void main(String [] args)
        {
            String s1 = "Computer";

            String s2 = s1.replace("Comp", "COMP");
 
            System.out.println("\n s1 = "+s1);
            System.out.println("\n s2 = "+s2);
        }
    }

/*
     String s2 = s1.replace(char, char);
     String s2 = s1.replace(String, String);
*/
   




