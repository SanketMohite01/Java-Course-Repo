
       import mypack.pack1.Abc;
    
    public class PackageDemo
    {
        public static void main(String [] args)
        {
             Abc obj = new Abc();
                 obj.show();
        }
    }
   
