
       import java.util.Scanner;
    
    public class WhileDemo3
    {
        public static void main(String [] args)
        {
           Scanner s = new Scanner(System.in);
             int num, i=1;

         System.out.println("\n Enter a num : ");
            num = s.nextInt();
 
            while(i <= 10)
            {
               System.out.println(num * i);
 
                  i++;
            }   
        }
    }
   
