
       package mypack.pack1;

   public class Abc
   {
       public void show()
       {
           System.out.println("show() of class Abc ");
       }
   }

/*
    compile - javac -d . Abc.java
*/



 