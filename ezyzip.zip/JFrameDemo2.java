
        import javax.swing.*;
        import java.awt.*;
        import java.awt.event.*;

      class MyFrame extends JFrame implements ActionListener
      {
           JButton b1, b2;
           JTextField t; 

           public MyFrame()
           {
               super("MYFRAME");
               setSize(700, 300);
               setLocation(400, 300);
               setResizable(false);
               setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
               setLayout(null);
 
               b1 = new JButton("CLICK");
               b1.setFont(new Font("Consolas", Font.BOLD, 22));
               b1.setForeground(Color.RED);
               b1.setBounds(30, 30, 100, 50);//x,y,w,h
               add(b1);                 

               t = new JTextField();
               t.setFont(new Font("Consolas", Font.BOLD, 22));
               t.setForeground(Color.BLACK);
               t.setBounds(150, 30, 250, 50);//x,y,w,h
               add(t);

               b2 = new JButton("CLEAR");
               b2.setFont(new Font("Consolas", Font.BOLD, 22));
               b2.setForeground(Color.RED);
               b2.setBounds(420, 30, 100, 50);//x,y,w,h
               add(b2);                 

               b1.addActionListener(this);
               b2.addActionListener(this);

               setVisible(true);             
           }

            public void actionPerformed(ActionEvent e)
            {
                if(e.getSource() == b1)
                {
                   t.setText("HELLO");
                }
                if(e.getSource() == b2)
                {
                   t.setText(" ");
                } 
            }
      } 

    public class JFrameDemo2
    {
        public static void main(String [] args)
        {
            new MyFrame();
        } 
    }

