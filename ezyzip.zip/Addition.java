
    public class Addition
    {
        public static void main(String [] args)
        {
             int a, b, c;
 
             a = 100;
             b = 200;
             c = a+b;

 System.out.println("\n Addition of "+a+" and "+b+" is "+c);
        }
    }
