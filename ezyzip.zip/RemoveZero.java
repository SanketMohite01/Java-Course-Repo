/*
    Q] Remove Zeros

   INPUT:
        1 2 3 4
        0 0 0 0
        3 4 2 1
        3 4 5 6 

  OUTPUT:
        1 2 3 4
        3 4 2 1
        3 4 5 6
*/

       import java.util.Scanner;
    
    public class RemoveZero
    {
        public static void main(String [] args)
        {
           Scanner s = new Scanner(System.in);
              int i, j, rsum=0, csum=0;
              
           int [][] A = new int[4][4]; 

         System.out.println("\n Enter 16 nums : ");
            for(i=0 ; i<4 ; i++)
            {
                for(j=0 ; j<4; j++)
                {
                   A[i][j] = s.nextInt(); 
                }
            }


          System.out.println("\n OUTPUT : ");

            for(i=0 ; i<4 ; i++)
            {
                   rsum = 0;
                   csum = 0;

                for(j=0 ; j<4; j++)
                {
                   rsum += A[i][j];
                   csum += A[j][i]; 
                } 

                if(rsum != 0)
                {
                    for(j=0 ; j<4 ; j++)
                    {
                       System.out.print(" "+A[i][j]);
                    } 
                       System.out.print("\n");
                }  
            }

     }
   }

   
