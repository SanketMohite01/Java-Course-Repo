
    public class Concat
    {
        public static void main(String [] args)
        {
            String s1 = "computer";
            String s2 = "programming";

          //  String s3 = s1.concat(s2); 
              String s3 = s1 + s2;               

            System.out.println("\n s3 = "+s3);
        }
    }
 




