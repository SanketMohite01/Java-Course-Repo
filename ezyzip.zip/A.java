
       package mypack.pack1;

     public class A
     {
         protected int i=100;

         public void show() 
         {
            System.out.println("\n i = "+i);  
         }
     }