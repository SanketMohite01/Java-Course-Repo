/*
     Q] Fibonacci Series 
         0   1   1   2   3   5.....
         a   b   c 
*/

       import java.util.Scanner;
    
    public class FibonacciSeries
    {
        public static void main(String [] args)
        {
           Scanner s = new Scanner(System.in);
            int a=0, b=1, c=1, n, i=1;

        System.out.println("\n Enter n :  ");
           n = s.nextInt();

        System.out.println("\n Fibonacci Series : ");
            while(i <= n)
            {
               System.out.print("  "+a);

                 a = b;
                 b = c;
                 c = a+b;
                  i++;
            }
        }
    }
   
