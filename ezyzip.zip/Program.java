
      import java.lang.*;

    public class Program
    {
        public static void main(String [] args)
        {
            System.out.println("HELLO");
        }
    }

/*
   compile - javac Program.java
   run     - java Program 

path : 
C:\Program Files\Java\jdk1.7.0_51\bin

MyComputer-> properties->Advanced System Settings->
Environment Variables -> System Variables -> Path
*/   


/*
     DATA TYPES in JAVA

  1] char - 'A', 'a', '@'
       2 bytes - UNICODE

  2] Integer Types

       byte  - 1 byte
       short - 2 bytes
       int   - 4 bytes
       long  - 8 bytes

 3] Floating Types

       float  - 4 bytes
       double - 8 bytes 
 
 4] boolean - 1 byte (true/false)

*/








