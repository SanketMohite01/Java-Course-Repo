/*
   HOMEWORK
    Q] WAP to find square root using for loop
 
          num = 25     ans = 5
          num = 100    ans = 10
----------------------------------------------------------
     Q] Find x raised to y using for loop

         x = 2
         y = 3

        ans = 2*2*2 = 8 
*/

       import java.util.Scanner;
    
    public class Power
    {
        public static void main(String [] args)
        {
           Scanner s = new Scanner(System.in);
              int x, y, i, ans=1;

          System.out.println("\n Enter x : ");
            x = s.nextInt();
 
          System.out.println("\n Enter y : ");
            y = s.nextInt();

           for(i=1 ; i<=y ; i++)
           {
               ans = ans * x;
           }

          System.out.println("\n Answer = "+ans);
        }
    }
   
