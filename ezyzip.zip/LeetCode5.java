/*
    Remove Duplicates
*/

       import java.util.Scanner;
    
    public class LeetCode5
    {
        public static void main(String [] args)
        {
           Scanner s = new Scanner(System.in);
           int size, i,j;
               
           System.out.println("\n Enter size : ");
              size = s.nextInt();

             int [] x = new int[size];

         System.out.println("\n Enter nums : ");
            for(i=0; i<size ; i++)
            {
                 x[i] = s.nextInt();  
            }

          for(i=0 ; i<size ; i++)
          {
              for(j=i+1 ; j<size ; j++)
              {
                  if(x[i] == x[j])
                  {
                     while(j < size-1)
                     {
                        x[j] = x[j+1];
                           j++; 
                     }  
                        size--;
                        i--;
                  }
              }
          }

         System.out.println("\n List : ");
            for(i=0; i<size ; i++)
            {
               System.out.print(" "+x[i]);    
            }
        }
    }
