/*
      Method Overriding
    Redefining a method in sub-class
*/


     class A
     {
         public void show()
         {
              System.out.println("\n show() in class A ");
         }
     }

     class B extends A
     {
         public void show()
         {
              System.out.println("\n show() in class B ");
                  super.show();
         }
     }
    
    public class MethodOverriding
    {
        public static void main(String [] args)
        {
              B obj = new B();
                obj.show();
        }
    }
   
