/*
   Q] WAP to convert decimal to binary using while loop

         num = 4     binary = 100
         num = 5     binary = 101
         num = 7     binary = 111
*/

       import java.util.Scanner;
    
    public class Dec2Bin
    {
        public static void main(String [] args)
        {
           Scanner s = new Scanner(System.in);
             int num, rem, bin=0, i=0;

            System.out.println("\n Enter a num : ");
              num = s.nextInt();

             while(num != 0)
             {
                rem = num % 2;

                bin = bin + (rem * (int)Math.pow(10, i));
                  i++;

                num = num / 2;
             }

            System.out.println("\n Binary = "+bin);
        }
    }
   
