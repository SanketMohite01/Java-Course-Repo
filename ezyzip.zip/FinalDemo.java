/*
        Final Classes in JAVA

  1] final classes are declared using keyword final.
  2] Final classes can not be inherited.
  3] They are mostly sub-classes.
 
        Final Methods in JAVA

  1] final methods are declared using keyword final.
  2] final methods can not be overridden in sub-classes.

*/

       class A
       {
           public final void show()
           {
           }
       }

       class B extends A
       {
           public void show()
           {
           }          
       } 

    public class FinalDemo
    {
        public static void main(String [] args)
        {
            
        }
    }
   
