
       package mypack.pack1;

     public class C
     {
          A obj = new A();
  
         public void show() 
         {
            System.out.println("\n i = "+obj.i);  
         }
     }
