
       import java.util.Scanner;
    
    public class IfDemo2
    {
        public static void main(String [] args)
        {
           Scanner s = new Scanner(System.in);
             
          System.out.println("\n Enter 3 nums : ");
            int a = s.nextInt();
            int b = s.nextInt();
            int c = s.nextInt();

           if(a>b && a>c)
           {
               System.out.println("\n max = "+a); 
           }
           else if(b>c)
           {
               System.out.println("\n max = "+b); 
           }
           else
           {
               System.out.println("\n max = "+c); 
           }

        }
    }



   
