/*
    Remove Duplicates
*/

       import java.util.Scanner;
    
    public class LeetCode6
    {
        public static void main(String [] args)
        {
           Scanner s = new Scanner(System.in);
           int size, i,j,k, max=0, start=0, end=0, sum=0;
               
           System.out.println("\n Enter size : ");
              size = s.nextInt();

             int [] x = new int[size];

         System.out.println("\n Enter nums : ");
            for(i=0; i<size ; i++)
            {
                 x[i] = s.nextInt();  
            }

   //     [-2 1 -3 4 -1 2 1 -5 4]

          for(i=0 ; i<size ; i++)
          {
              for(j=i ; j<size ; j++)
              {
                     sum=0;

                  for(k=i ; k<=j ; k++)
                  {
                     sum += x[k];
                  }

                   if(max <= sum)
                   {
                      max = sum;

                      start = i;
                      end = j;
                   } 
              }
          }

              sum=0;

           System.out.print("\n List = [");
            for(i=start; i<=end ; i++)
            {
               System.out.print(x[i]+", ");
                   sum += x[i];    
            }
  
               System.out.print("\b\b]");    

           System.out.print("\n sum = "+sum);
        }
    }

