/*
   Q] Find max & max2 in a given array
*/

       import java.util.Scanner;
    
    public class ArrayDemo4
    {
        public static void main(String [] args)
        {
           Scanner s = new Scanner(System.in);
                int size, i, max, max2;

           System.out.println("\n Enter size : ");
              size = s.nextInt();

             int [] x = new int[size];

         System.out.println("\n Enter nums : ");
            for(i=0; i<size ; i++)
            {
                 x[i] = s.nextInt();  
            }

               max = 0;

            for(i=0 ; i<size ; i++)
            {
                if(max < x[i])
                {
                   max = x[i]; 
                } 
            }

                max2 = 0;      

            for(i=0 ; i<size ; i++)
            {
                if(max2 < x[i] && x[i]!=max)
                {
                   max2 = x[i]; 
                } 
            }

         System.out.println("\n max = "+max);
         System.out.println("\n max2 = "+max2);
        }
    }
