/*

   Q] WAP to convert decimal to binary using while loop

         num = 4     binary = 100
         num = 5     binary = 101
         num = 7     binary = 111

------------------------------------------------
    Q] Palindrome Number

         num = 121
*/

       import java.util.Scanner;
    
    public class PalidromeNumber
    {
        public static void main(String [] args)
        {
           Scanner s = new Scanner(System.in);
               int num, rem, rev=0, temp;

            System.out.println("\n Enter a num : ");
              num = s.nextInt();

              temp = num;

              while(num != 0)
              {
                 rem = num % 10;
                 rev = (rev * 10) + rem;
                 num = num / 10;
              }

           if(rev == temp)
             System.out.println("\n Palindrome Number");
           else
             System.out.println("\n NOT a Palindrome Number");

        }
    }
   
