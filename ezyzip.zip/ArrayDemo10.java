/*
   Q] Program to check ASC / DESC / NOT IN ORDER

      x[]={1,2,3,4,5};   ASC ORDER
      x[]={5,4,3,2,1};   DESC ORDER
      x[]={1,5,3,2,4};   NOT IN ORDER
*/

       import java.util.Scanner;
    
    public class ArrayDemo10
    {
        public static void main(String [] args)
        {
           Scanner s = new Scanner(System.in);
             int size, i, c1=0, c2=0;
               
           System.out.println("\n Enter size : ");
              size = s.nextInt();

             int [] x = new int[size];

         System.out.println("\n Enter nums : ");
            for(i=0; i<size ; i++)
            {
                 x[i] = s.nextInt();  
            }

           for(i=0 ; i<size-1 ; i++)
           {
              if(x[i] <= x[i+1])
              {
                   c1++;
              }  
              else if(x[i] >= x[i+1])
              {
                   c2++;
              }  
           }

           if(c1 == size-1)
           {
              System.out.println("\n ASC ORDER ");  
           }
           else if(c2 == size-1)
           {
              System.out.println("\n DESC ORDER ");  
           } 
           else
           {
              System.out.println("\n NOT IN ORDER ");  
           } 
        }
    }
