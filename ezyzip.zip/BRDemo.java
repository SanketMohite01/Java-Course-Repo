
       import java.io.*;
    
    public class BRDemo
    {
        public static void main(String [] args)
        {

    try
    {   
BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

          System.out.println("\n Enter 2 nums : ");

           int a = Integer.parseInt(br.readLine());
           int b = Integer.parseInt(br.readLine());

            System.out.println("\n Add = "+(a+b));
    }
    catch(Exception e)
    {}

        }
    }
   
