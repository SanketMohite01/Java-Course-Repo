 
    public class LastIndexOf
    {
        public static void main(String [] args)
        {
            String s1 = "CompCuterC";

            int i = s1.lastIndexOf("D", 3);

            System.out.println("\n i = "+i);
        }
    }

/*
      int i = s1.lastIndexOf(char);
      int i = s1.lastIndexOf(char, int);
      int i = s1.lastIndexOf(String);
      int i = s1.lastIndexOf(String, int);

NOTE - indexOf() returns -1 if given char/String is not present
*/

 







