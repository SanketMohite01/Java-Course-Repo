
    public class CharAt
    {
        public static void main(String [] args)
        {
            String s1 = "computer";

            char ch = s1.charAt(0); 
 
            System.out.println("\n ch = "+ch);
        }
    }
 




