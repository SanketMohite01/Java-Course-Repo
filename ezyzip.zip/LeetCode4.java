/*
    Two Sum
*/

       import java.util.Scanner;
    
    public class LeetCode4
    {
        public static void main(String [] args)
        {
           Scanner s = new Scanner(System.in);
           int size, i=0, j=0, num, pos1=0, pos2=0;
               
           System.out.println("\n Enter size : ");
              size = s.nextInt();

             int [] x = new int[size];

         System.out.println("\n Enter nums : ");
            for(i=0; i<size ; i++)
            {
                 x[i] = s.nextInt();  
            }

           System.out.println("\n Enter target number : ");
              num = s.nextInt();

        for(i=0 ; i<size ; i++)
        {
            for(j=i+1 ; j<size ; j++)
            {
               if((x[i]+x[j]) == num)
               {
                    pos1 = i;
                    pos2 = j;
                    break;
               }
            }
        }  

        System.out.println("\n ["+pos1+", "+pos2+"]");
        }
    }
