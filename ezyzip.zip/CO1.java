
       import java.util.Scanner;
    
      class Abc
      {
          public void add()
          {
              Scanner s = new Scanner(System.in);

             System.out.println("\n Enter 2 nums : ");
                int a = s.nextInt();
                int b = s.nextInt();
  
             System.out.println("\n Addition = "+(a+b));               
          }
      }

    public class CO1
    {
        public static void main(String [] args)
        {
             Abc obj = new Abc();
                 obj.add();
        }
    }
   
