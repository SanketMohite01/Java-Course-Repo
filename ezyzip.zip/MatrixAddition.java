/*
        Matrix Addition
*/

       import java.util.Scanner;
    
    public class MatrixAddition
    {
        public static void main(String [] args)
        {
           Scanner s = new Scanner(System.in);
 
              int [][] A = new int[3][3];
              int [][] B = new int[3][3];
              int [][] C = new int[3][3];
                   int i, j;

            System.out.println("\n Enter 9 nums : ");     
                for(i=0 ; i<3; i++)
                  for(j=0 ; j<3; j++)
                    A[i][j] = s.nextInt();

            System.out.println("\n Enter 9 nums : ");     
                for(i=0 ; i<3; i++)
                  for(j=0 ; j<3; j++)
                    B[i][j] = s.nextInt();

            System.out.println("\n Matrix after add : ");     
                for(i=0 ; i<3; i++)
                {
                   for(j=0 ; j<3; j++)
                   {
                       C[i][j] = A[i][j] + B[i][j];

                       System.out.print(" "+C[i][j]);      
                   }
                       System.out.print("\n");      
                }   
        }
    }
   
