
    public class Trim
    {
        public static void main(String [] args)
        {
            String s1 = "  I love java  ";

            String s2 = s1.trim();
 
            System.out.println("\n s1 = "+s1);
            System.out.println("\n s2 = "+s2);
        }
    }
 




