
       import java.util.Scanner;
    
    public class IfDemo1
    {
        public static void main(String [] args)
        {
           Scanner s = new Scanner(System.in);
             
          System.out.println("\n Enter 2 nums : ");
            int a = s.nextInt();
            int b = s.nextInt();

           if(a>b)
           {
               System.out.println("\n max = "+a); 
           }
           else
           {
               System.out.println("\n max = "+b); 
           }
        }
    }



   
