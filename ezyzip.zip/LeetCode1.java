/*
   Q] Container with most water
*/
    
    public class LeetCode1
    {
        public static void main(String [] args)
        {
            int [] heights={1,8,6,2,5,4,8,3,7};
            int i,j, width, height, maxarea=0;

            for(i=0 ; i<heights.length ; i++)
            {
                for(j=i+1 ; j<heights.length; j++)
                {
                    width = j-i;
           height = (heights[i]<heights[j])?heights[i]:heights[j];
                   
                    if(maxarea <= (width*height))
                    {
                        maxarea = width*height;
                    }
                } 
            }
 
            System.out.println("\n maxarea = "+maxarea);
        }
    }
