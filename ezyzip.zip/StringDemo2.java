
    public class StringDemo2
    {
        public static void main(String [] args)
        {
             String s1 = "Java";
             String s2 = "Java";
 
             String s3 = new String("Java");
             String s4 = new String("Java");

            if(s3.equals(s4))
            {
                System.out.println("\n SAME ");
            }
            else
            {
                System.out.println("\n NOT SAME ");
            }
        }
    }







