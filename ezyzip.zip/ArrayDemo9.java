/*
   Q] Linear Sort
*/

       import java.util.Scanner;
    
    public class ArrayDemo9
    {
        public static void main(String [] args)
        {
           Scanner s = new Scanner(System.in);
             int size, i, j, temp;
               
           System.out.println("\n Enter size : ");
              size = s.nextInt();

             int [] x = new int[size];

         System.out.println("\n Enter nums : ");
            for(i=0; i<size ; i++)
            {
                 x[i] = s.nextInt();  
            }

           for(i=0 ; i<size ; i++)
           {
               for(j=i+1 ; j<size ; j++)
               {
                   if(x[i] > x[j])
                   {
                       temp = x[i];
                       x[i] = x[j];
                       x[j] = temp;  
                   }
               }
           }

            System.out.println("\n List after sort : ");
                for(int a : x)
                {
                   System.out.print("  "+a); 
                }
        }
    }

