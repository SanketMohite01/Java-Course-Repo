/*
     Multilevel Inheritance
*/

     class A 
     {
         public A()
         {
            System.out.println("\n CONS A ");
         }
     }

     class B extends A 
     {
         public B()
         {
            System.out.println("\n CONS B ");
         }
     }

     class C extends B 
     {
         public C()
         {
            System.out.println("\n CONS C ");
         }
     }

   public class MultilevelInheritance 
   {
       public static void main(String [] args)
       {
            C obj = new C();
       }
   }