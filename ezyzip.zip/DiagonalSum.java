
       import java.util.Scanner;
    
    public class DiagonalSum
    {
        public static void main(String [] args)
        {
           Scanner s = new Scanner(System.in);
 
              int [][] A = new int[3][3];
                int i, j, fd=0, bd=0;

            System.out.println("\n Enter 9 nums : ");     
                for(i=0 ; i<3; i++)
                  for(j=0 ; j<3; j++)
                    A[i][j] = s.nextInt();


                for(i=0 ; i<3; i++)
                {
                   for(j=0 ; j<3; j++)
                   {
                       if(i == j)
                       {
                           fd += A[i][j];
                       }
                       if(i+j == 2)
                       {
                           bd += A[i][j];
                       }
                   }
                }   

            System.out.println("\n Sum of for diag ele = "+fd);     
            System.out.println("\n Sum of back diag ele = "+bd);     
        }
    }
   