
    public class Length
    {
        public static void main(String [] args)
        {
            String s1 = "computer";

            int i = s1.length();
 
            System.out.println("\n i = "+i);
        }
    }
 




