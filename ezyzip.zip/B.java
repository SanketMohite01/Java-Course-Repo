
       package mypack.pack1;

     public class B extends A
     {
         public void show() 
         {
            System.out.println("\n i = "+i);  
         }
     }