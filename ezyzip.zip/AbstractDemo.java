/*
       Abstract Classes in JAVA
 
 1] Abstract classes are declared using keyword abstarct.
 2] They can not be instantiated.
 3] They are mostly super-classes.
 4] It can contain constructors, abstract-methods & non-abstract methods

       Abstract Methods in JAVA
 
 1] Abstract methods are declared using keyword abstarct.
 2] It must be declared inside abstract-class only.
 3] It does not have implementation code.
    It's declaration ends with semicolon(;).
 4] Abstract methods must be overridden in non-abstarct sub-classes.

*/

      abstract class A
      {
          public A() 
          {
          }

          public void show()
          {
          }

            public abstract void add(int a, int b);
      }
 
      class B extends A
      {
            public void add(int a, int b)
            {
            }
      }
    
    public class AbstractDemo
    {
        public static void main(String [] args)
        {
          
        }
    }
   
