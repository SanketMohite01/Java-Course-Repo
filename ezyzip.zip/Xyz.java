
       package mypack.pack1;

   public class Xyz
   {
       public void disp()
       {
           System.out.println("disp() of class Xyz ");
       }
   }

/*
    compile - javac -d . Xyz.java
*/




 