/*
    Q] Count Vowels

       str = "Panvel"
       count = 2
*/

       import java.util.Scanner;
    
    public class CountVowels
    {
        public static void main(String [] args)
        {
           Scanner s = new Scanner(System.in);
              int i, count=0;
            
         System.out.println("\n Enter a string : ");
            String str = s.nextLine();
 
          for(i=0 ; i<str.length() ; i++)
          {
              switch(str.charAt(i))
              {
                 case 'a':
                 case 'e':
                 case 'i':
                 case 'o':
                 case 'u':
                 case 'A':
                 case 'E':
                 case 'I':
                 case 'O':
                 case 'U':
                           count++;
              }
          }

           System.out.println("\n count = "+count);
     }
   }

   
