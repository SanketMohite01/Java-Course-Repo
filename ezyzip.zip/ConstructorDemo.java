/*
        Constructor in JAVA
 
  1] It is a special method with same name as class-name.
  2] It has no return type. Not even void.
  3] It gets called automatically when we create an object of class. 
  4] It allocates memory for an object.
  5] It is used to assign initial values to data members in class. 

NOTE :-
If there is no constructor present in class then compiler provides
one default cons.
But, if there is a parameterised constructor present in class then 
no default constructor is provided. 
*/
 
     class Abc
     {
          int a, b;

         public Abc()  // Default cons
         {
             a = 10;
             b = 20; 
         }

         public Abc(int x, int y)  // parameterised cons
         {
             a = x;
             b = y; 
         }

         public void show()
         {
             System.out.println("\n a = "+a);
             System.out.println("\n b = "+b);
         } 
     }
    
    public class ConstructorDemo
    {
        public static void main(String [] args)
        {
             Abc A = new Abc();
                 A.show(); 

             Abc B = new Abc(11, 22);
                 B.show();

             Abc C = new Abc(100, 200);
                 C.show();

              new Abc(1000, 2000).show();
        }
    }



   
