/*
    Leetcode 66.Plus One
*/

       import java.util.Scanner;
    
    public class LeetCode7
    {
        public static void main(String [] args)
        {
           Scanner s = new Scanner(System.in);
           int size, i,j,sum=0, num=0, temp;
               
           System.out.println("\n Enter size : ");
              size = s.nextInt();

             int [] x = new int[size];
             int [] y = new int[size+1];

         System.out.println("\n Enter nums : ");
            for(i=0; i<size ; i++)
            {
                 x[i] = s.nextInt();  
            }

            for(i=0; i<size ; i++)
            {
                num += x[i] * (int)Math.pow(10, x.length-1-i);  
            }
           
           System.out.print("\n num = "+num);
               num++;
           System.out.print("\n num+1 = "+num);
  
             i=0;
            int count=0;

           while(num != 0)
           {
               y[i] = num % 10;
               i++;
               num = num / 10;
                count++;   
           } 

          for(j=0; j<=i ; j++)
          {
              temp = y[j];
              y[j] = y[--i];
              y[i] = temp;
          } 

         System.out.println("\n OUTPUT : ");
            for(i=0; i<count ; i++)
            {
               System.out.print(" "+y[i]);    
            }              
        }
    }

