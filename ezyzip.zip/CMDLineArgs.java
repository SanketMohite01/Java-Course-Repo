
    public class CMDLineArgs
    {
        public static void main(String [] args)
        {
            int a = Integer.parseInt(args[0]); 
            int b = Integer.parseInt(args[1]); 

            System.out.println("\n Add = "+(a+b));
        }
    }
   
/*
    compile - javac CMDLineArgs.java
    run     - java  CMDLineArgs 10 20
*/



