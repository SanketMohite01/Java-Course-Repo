 
    public class IndexOf
    {
        public static void main(String [] args)
        {
            String s1 = "CompCuterC";

            int i = s1.indexOf("Comp");

            System.out.println("\n i = "+i);
        }
    }

/*
      int i = s1.indexOf(char);
      int i = s1.indexOf(char, int);
      int i = s1.indexOf(String);
      int i = s1.indexOf(String, int);

NOTE - indexOf() returns -1 if given char/String is not present
*/

 







