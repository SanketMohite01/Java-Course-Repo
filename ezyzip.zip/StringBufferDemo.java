
    public class StringBufferDemo
    {
        public static void main(String [] args)
        {
           StringBuffer str = new StringBuffer("Computer");

              str.append("Programming");
              str.insert(0, "Java");
              str.setCharAt(0, 'j');
              str.reverse();

           System.out.println("\n str = "+str); 
        }
    }








