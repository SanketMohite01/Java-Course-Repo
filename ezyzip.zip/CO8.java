
          import java.util.Scanner;
 
       class Abc
       {
           public void sort(int [] y, int size)
           {
                int i, j, temp;

                for(i=0 ; i<size ; i++)
                {
                    for(j=i+1 ; j<size ; j++)
                    {
                        if(y[i] > y[j])
                        {
                           temp = y[i];
                           y[i] = y[j];
                           y[j] = temp;      
                        }
                    }
                }
           }
       }

    public class CO8
    {
        public static void main(String [] args)
        {
            Scanner s = new Scanner(System.in);
                int size, i;
  
           System.out.println("\n Enter size : ");
                size = s.nextInt();
 
             int [] x = new int[size];

           System.out.println("\n Enter nums : ");
              for(i=0; i<size ; i++)
              {
                  x[i] = s.nextInt();
              }
 
               Abc obj = new Abc();
                obj.sort(x, size); 

          System.out.println("\n List after sort : ");
              for(int a : x) // foreach int a in x
              {
                 System.out.print(" "+a);
              }   
        }
    }
   
