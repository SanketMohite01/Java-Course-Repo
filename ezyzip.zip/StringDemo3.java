
       import java.util.Scanner;
    
    public class StringDemo3
    {
        public static void main(String [] args)
        {
           Scanner s = new Scanner(System.in);

         System.out.println("\n Enter a string : ");
            String str = s.nextLine();

         System.out.println("\n str =  "+str);

        }
    }
   
